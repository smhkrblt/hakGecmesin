//
//  ViewController.swift
//  almanUsuluDenem
//
//  Created by SEmih Karabulut on 18.01.2022.
//

import UIKit

class ViewController: UIViewController {
    
    var semihHesapDouble:Double = 0.0
    var semihHesapString = ""
    var arifHesapDouble:Double = 0.0
    var arifHesapString = ""
    var toplamGider:Double = 0.0
    var yariYariya:Double = 0.0
    var semihFark:Double = 0.0
    var arifFark:Double = 0.0
  
    @IBOutlet weak var semihGiderLabel: UILabel!
    @IBOutlet weak var semihGiderTextfield: UITextField!
    
    @IBOutlet weak var arifGiderLabel: UILabel!
    @IBOutlet weak var arifGiderTextfield: UITextField!
    
    @IBOutlet weak var toplamGiderLabel: UILabel!
    
    @IBOutlet weak var semihFarkLabel: UILabel!
    @IBOutlet weak var islemLabel: UILabel!
    @IBOutlet weak var arifFarkLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboard()
        
        
        
    }
    @IBAction func semihEkleButton(_ sender: Any) {
        
        semihEkle()
        toplamGider = semihHesapDouble + arifHesapDouble
        semihGiderLabel.text = "\(semihHesapDouble) TL"
        toplamGiderLabel.text = String("\(toplamGider) TL")
        semihGiderTextfield.text = ""
        ikiyebol()
        hesapla()

    }
    
    
    @IBAction func arifEkleButton(_ sender: Any) {
        arifEkle()
        toplamGider = semihHesapDouble + arifHesapDouble
        arifGiderLabel.text = "\(arifHesapDouble) TL"
        toplamGiderLabel.text = String("\(toplamGider) TL")
        arifGiderTextfield.text = ""
        ikiyebol()
        hesapla()
        
    }
    
    @IBAction func hesapKapatButton(_ sender: Any) {
        semihHesapDouble = 0.0
        semihHesapString = ""
        arifHesapDouble = 0.0
        arifHesapString = ""
        toplamGider = 0.0
        yariYariya = 0.0
        semihFark = 0.0
        arifFark = 0.0
        semihGiderLabel.text = "0 TL"
        arifGiderLabel.text = "0 TL"
        toplamGiderLabel.text = "0 TL"
        semihFarkLabel.text = "0 TL"
        arifFarkLabel.text = "0 TL"
        islemLabel.text = "="
        
    }
    
        
    
    func semihEkle() {
        semihHesapString = semihGiderTextfield.text!
        semihHesapDouble = semihHesapDouble + Double(semihHesapString)!
        
    }
    
    func arifEkle() {
        arifHesapString = arifGiderTextfield.text!
        arifHesapDouble = arifHesapDouble + Double(arifHesapString)!
    }

    func ikiyebol() {
        yariYariya = toplamGider / 2
    }
    
    func hesapla() {
        if semihHesapDouble > yariYariya {
            arifFarkLabel.text = "\(semihHesapDouble-yariYariya) TL"
            semihFarkLabel.text = "Alacaklı"
            islemLabel.text = "<"
        }else if semihHesapDouble < yariYariya {
            semihFarkLabel.text = "\(arifHesapDouble-yariYariya) TL"
            arifFarkLabel.text = "Alacaklı"
            islemLabel.text = ">"}
        else if semihHesapDouble == arifHesapDouble{
            semihFarkLabel.text = "0 TL"
            arifFarkLabel.text = "0 TL"
            islemLabel.text = "="
        }
    }

}
extension UIViewController{
    func hideKeyboard(){
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dissmissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
        }
    
    @objc func dissmissKeyboard() {
        view.endEditing(true)
    }
    
}
